export const server = {
  port: 3333,
};

export const database = {
  host: 'localhost',
  port: 5432,
};
